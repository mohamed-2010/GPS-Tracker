@extends ('layouts.in')

@section ('body')

<form method="POST" action="{{ route('geofence.store') }}">
    @csrf

    <div class="box p-5 mt-5">
        <div class="p-2">
            <h2 class="text-lg font-medium mb-4">{{ __('Create New Geofence') }}</h2>

            <div class="mb-4">
                <label for="geofence-name" class="form-label">{{ __('Name') }}</label>
                <input type="text" name="name" id="geofence-name" class="form-control" value="{{ $geofence->name }}" required>
            </div>

            <div class="mb-4">
                <label for="geofence-type" class="form-label">{{ __('Type') }}</label>
                <select name="type" id="geofence-type" class="form-control" required>
                    <option value="polygon" {{ $geofence->type === 'polygon' ? 'selected' : '' }}>{{ __('Polygon') }}</option>
                    <option value="circle" {{ $geofence->type === 'circle' ? 'selected' : '' }}>{{ __('Circle') }}</option>
                </select>
            </div>

            <div class="mb-4">
                <label class="form-label">{{ __('Draw Geofence on Map') }}</label>
                <div id="map" style="height: 500px; border-radius: 8px;"></div>
                <input type="hidden" name="geometry" id="geometry-data" required>
            </div>

            <div class="mb-4">
                <label for="geofence-color" class="form-label">{{ __('Color') }}</label>
                <input type="color" name="color" id="geofence-color" class="form-control" value="{{ $geofence->color ?: '#3B82F6' }}">
            </div>

            <div class="text-right">
                <a href="{{ url()->previous() }}" class="btn btn-secondary mr-2">{{ __('Cancel') }}</a>
                <button type="submit" class="btn btn-primary">{{ __('Create Geofence') }}</button>
            </div>
        </div>
    </div>
</form>

@stop

@push('js')
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const map = L.map('map').setView([30.0444, 31.2357], 6);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    const drawnItems = new L.FeatureGroup();
    map.addLayer(drawnItems);

    const drawControl = new L.Control.Draw({
        position: 'topright',
        draw: {
            polygon: {
                allowIntersection: false,
                shapeOptions: {
                    color: document.getElementById('geofence-color').value
                }
            },
            circle: {
                shapeOptions: {
                    color: document.getElementById('geofence-color').value
                }
            },
            polyline: false,
            marker: false,
            rectangle: false,
            circlemarker: false
        },
        edit: {
            featureGroup: drawnItems,
            remove: true
        }
    });
    map.addControl(drawControl);

    map.on('draw:created', function(e) {
        const layer = e.layer;
        drawnItems.clearLayers();
        drawnItems.addLayer(layer);
        
        let geometry;
        if (e.layerType === 'circle') {
            const center = layer.getLatLng();
            const radius = layer.getRadius();
            geometry = JSON.stringify({
                type: 'circle',
                center: [center.lat, center.lng],
                radius: radius
            });
        } else if (e.layerType === 'polygon') {
            const latlngs = layer.getLatLngs()[0];
            const coordinates = latlngs.map(ll => [ll.lat, ll.lng]);
            geometry = JSON.stringify({
                type: 'polygon',
                coordinates: [coordinates]
            });
        }
        
        document.getElementById('geometry-data').value = geometry;
    });

    document.getElementById('geofence-color').addEventListener('change', function(e) {
        drawnItems.eachLayer(function(layer) {
            layer.setStyle({ color: e.target.value });
        });
    });
});
</script>
@endpush

@push('css')
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<link rel="stylesheet" href="https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.css" />
@endpush
