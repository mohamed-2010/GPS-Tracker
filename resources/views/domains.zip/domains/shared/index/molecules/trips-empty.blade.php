<img class="m-auto mt-10 lg:mt-20 h-60" src="@asset('build/images/trip.svg')">
