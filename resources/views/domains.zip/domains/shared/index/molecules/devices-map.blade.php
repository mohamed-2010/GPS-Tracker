@include ('domains.shared.index.molecules.map-filters')

<x-map-device :devices="$devices"></x-map-device>
